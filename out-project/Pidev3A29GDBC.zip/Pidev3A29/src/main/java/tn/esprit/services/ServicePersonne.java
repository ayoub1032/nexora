package tn.esprit.services;

import tn.esprit.entities.Personne;
import tn.esprit.utils.MyDataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ServicePersonne implements IService<Personne> {
    private Connection connection;

    public ServicePersonne(){
        connection = MyDataBase.getInstance().getMyConnection();
    }
    @Override
    public void ajouter(Personne personne) throws SQLException {
        String sql ="INSERT INTO `personne`(`nom`, `prenom`, `age`) VALUES ('"+personne.getNom()+"','"+personne.getPrenom()+"',"+personne.getAge()+")";
        Statement statement = connection.createStatement();
        statement.executeUpdate(sql);

    }

    @Override
    public void modifier(Personne personne) throws SQLException {
        String sql ="UPDATE `personne` SET `nom`=?,`prenom`=?,`age`=? WHERE id= ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, personne.getNom());
        ps.setString(2, personne.getPrenom());
        ps.setInt(3, personne.getAge());
        ps.setInt(4, personne.getId());
        ps.executeUpdate();

    }

    @Override
    public void supprimer(int id) throws SQLException {
        String sql = "Delete from personne where id =?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setInt(1,id);
        ps.executeUpdate();

    }

    @Override
    public List<Personne> afficher() throws SQLException {
        List<Personne> personnes= new ArrayList<>();
        String sql = "Select * from personne";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
        while (resultSet.next()){
            Personne p = new Personne();
            p.setId(resultSet.getInt("id"));
            p.setNom(resultSet.getString(2));
            p.setPrenom(resultSet.getString(3));
            p.setAge(resultSet.getInt(4));
            personnes.add(p);
        }
        return personnes;
    }
}
